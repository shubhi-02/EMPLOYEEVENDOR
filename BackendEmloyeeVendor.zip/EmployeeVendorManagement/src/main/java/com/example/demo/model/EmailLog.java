package com.example.demo.model;



import jakarta.persistence.*;
import lombok.Data;

@Entity
public class EmailLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String recipient;
    private String subject;
    private String content;
    private String timestamp;
	public void setRecipient(String email) {
		// TODO Auto-generated method stub
		
	}
	public void setSubject(String subject2) {
		// TODO Auto-generated method stub
		
	}
	public void setTimestamp(String format) {
		// TODO Auto-generated method stub
		
	}
}
