package com.example.demo.service;



import com.example.demo.model.EmailLog;
import com.example.demo.model.Vendor;
import com.example.demo.repository.EmailLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class EmailService {

    @Autowired
    private EmailLogRepository emailLogRepository;

    public void sendEmail(Vendor vendor) {
        String subject = "Payment Details";
        String content = String.format("Sending payments to vendor %s at UPI %s", vendor.getName(), vendor.getUpi());

        // Simulate sending email by printing to console
        System.out.println("Sending email to " + vendor.getEmail());
        System.out.println("Subject: " + subject);
        System.out.println("Content: " + content);

        // Log email
        EmailLog emailLog = new EmailLog();
        emailLog.setRecipient(vendor.getEmail());
        emailLog.setSubject(subject);
        emailLog.setRecipient(content);
        emailLog.setTimestamp(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        emailLogRepository.save(emailLog);
    }
}

