package com.example.demo.repository;



import com.example.demo.model.EmailLog;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmailLogRepository extends JpaRepository<EmailLog, Long> {

	void save(EmailLog emailLog);

	List<EmailLog> findAll();
}
