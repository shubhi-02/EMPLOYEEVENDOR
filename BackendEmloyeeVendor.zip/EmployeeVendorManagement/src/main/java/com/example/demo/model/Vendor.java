package com.example.demo.model;



import jakarta.persistence.*;
import lombok.Data;

@Entity

public class Vendor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String upi;

    @Column(unique = true)
    private String email;

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getUpi() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
}
