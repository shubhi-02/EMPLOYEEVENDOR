package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.model.Vendor;
import com.example.demo.service.AdminService;
import com.example.demo.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private EmailService emailService;

    @PostMapping("/employees")
    public Employee createEmployee(@RequestBody Employee employee) {
        return adminService.saveEmployee(employee);
    }

    @PostMapping("/vendors")
    public Vendor createVendor(@RequestBody Vendor vendor) {
        return adminService.saveVendor(vendor);
    }

    @GetMapping("/employees")
    public List<Employee> getAllEmployees() {
        return adminService.getAllEmployees();
    }

    @GetMapping("/vendors")
    public List<Vendor> getAllVendors() {
        return adminService.getAllVendors();
    }

    @PostMapping("/send-email")
    public void sendEmail(@RequestBody Vendor vendor) {
        emailService.sendEmail(vendor);
    }
}
