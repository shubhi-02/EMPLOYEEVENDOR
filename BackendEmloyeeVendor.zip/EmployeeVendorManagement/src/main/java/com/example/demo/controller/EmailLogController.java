package com.example.demo.controller;



import com.example.demo.model.EmailLog;
import com.example.demo.repository.EmailLogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/emails")
@CrossOrigin(origins = "http://localhost:3000")
public class EmailLogController {

    @Autowired
    private EmailLogRepository emailLogRepository;

    @GetMapping
    public List<EmailLog> getAllEmailLogs() {
        return emailLogRepository.findAll();
    }
}
