package com.example.demo.model;



import jakarta.persistence.*;
import lombok.Data;

@Entity

public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String designation;
    private Double CTC;

    @Column(unique = true)
    private String email;
}
