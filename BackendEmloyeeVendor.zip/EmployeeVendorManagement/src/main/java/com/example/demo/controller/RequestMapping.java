package com.example.demo.controller;

public @interface RequestMapping {

	String value();

}
