package org.springframework.data.jpa.repository;

public class JpaRepository {

}
