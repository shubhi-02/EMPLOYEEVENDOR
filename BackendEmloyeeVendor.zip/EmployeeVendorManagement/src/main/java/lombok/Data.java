package lombok;

public class Data {

}
